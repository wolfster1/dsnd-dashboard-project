from setuptools import setup, find_packages

setup(
    name="employee_events",
    version="0.1",
    packages=find_packages(),
    install_requires=["pandas", "matplotlib"],  
)
